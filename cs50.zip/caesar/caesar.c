#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

bool only_digits(string s);
char rotate(char c, int key);

int main(int argc, string argv[])
{
    // Check for valid argument count and key
    if (argc == 2 && only_digits(argv[1]))
    {
        // Convert the key to int
        int key = atoi(argv[1]);

        // Prompt the user for the plaintext
        string plain = get_string("plaintext:  ");

        // For every char in the plaintext, rotate and print it
        printf("ciphertext: ");
        for (int i = 0, len = strlen(plain); i < len; i++)
        {
            printf("%c", rotate(plain[i], key));
        }
        printf("\n");
    }
    else
    {
        // Usage instructions
        printf("Usage: ./caesar key\n");
        return 1;
    }
}

// Checks whether a string only has digits
bool only_digits(string s)
{
    for (int i = 0, len = strlen(s); i < len; i++)
    {
        if (!isdigit(s[i]))
        {
            return false;
        }
    }
    return true;
}

// Returns a rotated char based on CAse
char rotate(char c, int key)
{
    if (isupper(c))
    {
        return ((c - 'A' + key) % 26 + 'A');
    }
    else if (islower(c))
    {
        return ((c - 'a' + key) % 26 + 'a');
    }
    else
    {
        return c;
    }
}