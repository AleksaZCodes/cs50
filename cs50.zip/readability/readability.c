#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

int count_letters(string text);
int count_words(string text);
int count_sentences(string text);

int main(void)
{
    // Get the text
    string text = get_string("Text: ");

    // Count the number of letters, words and sentences
    int letters = count_letters(text);
    int words = count_words(text);
    int sentences = count_sentences(text);

    // Calculate L (letters per 100 words) and S (sentences per 100 words)
    float L = letters * 100.0 / words;
    float S = sentences * 100.0 / words;

    // Calculate the index
    int index = round(0.0588 * L - 0.296 * S - 15.8);

    // Output according to the index
    if (index < 1)
    {
        printf("Before Grade 1\n");
    }
    else if (index >= 16)
    {
        printf("Grade 16+\n");
    }
    else
    {
        printf("Grade %i\n", index);
    }
}

// Counts alpha characters (letters) in a string
int count_letters(string text)
{
    int counter = 0;

    for (int i = 0, len = strlen(text); i < len; i++)
    {
        if (isalpha(text[i]))
        {
            counter++;
        }
    }

    return counter;
}

// Counts words by counting spaces +1
int count_words(string text)
{
    int counter = 1;

    for (int i = 0, len = strlen(text); i < len; i++)
    {
        if (text[i] == ' ')
        {
            counter++;
        }
    }

    return counter;
}

// Counts sentences by counting '.'s, '!'s and '?'s
int count_sentences(string text)
{
    int counter = 0;

    for (int i = 0, len = strlen(text); i < len; i++)
    {
        if (text[i] == '.' || text[i] == '!' || text[i] == '?')
        {
            counter++;
        }
    }

    return counter;
}