#include <cs50.h>
#include <stdio.h>
#include <string.h>

const int BITS_IN_BYTE = 8;

void print_bulb(int bit);
void to_bits(string message, int len, int bits[]);

int main(void)
{
    // Prompt the user for a string and get its size
    string message = get_string("Message: ");
    int len = strlen(message);

    // Make an array and fill it with chars converted to bits
    int bits[len * BITS_IN_BYTE];
    to_bits(message, len, bits);

    for (int i = 1; i <= len * BITS_IN_BYTE; i++)
    {
        // Print a bulb
        print_bulb(bits[i - 1]);

        // Go to the new line if finished a byte
        if (i % BITS_IN_BYTE == 0)
        {
            printf("\n");
        }
    }
}

void print_bulb(int bit)
{
    if (bit == 0)
    {
        // Dark emoji
        printf("\U000026AB");
    }
    else if (bit == 1)
    {
        // Light emoji
        printf("\U0001F7E1");
    }
}

void to_bits(string message, int len, int bits[])
{
    for (int i = 0; i < len; i++)
    {
        int character = message[i];
        int index = i * BITS_IN_BYTE + BITS_IN_BYTE - 1;
        for (int j = index; j > index - BITS_IN_BYTE; j--)
        {
            bits[j] = character % 2;
            character = character / 2;
        }
    }
}
