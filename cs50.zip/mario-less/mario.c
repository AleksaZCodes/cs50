#include <cs50.h>
#include <stdio.h>

int main(void)
{
    // Prompt the user for height in interval [1, 8]
    int height;
    do
    {
        height = get_int("Height: ");
    }
    while (!(1 <= height && height <= 8));

    // For line with starting number of 1
    for (int i = 1; i < height + 1; i++)
    {
        // Print a space {height - line number} times
        for (int j = 0; j < height - i; j++)
        {
            printf(" ");
        }

        // Print a hashtag {line number} times
        for (int j = 0; j < i; j++)
        {
            printf("#");
        }

        // Go to the next line
        printf("\n");
    }
}