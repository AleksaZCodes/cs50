#include <cs50.h>
#include <stdio.h>

void line(string text, int n);

int main(void)
{
    // Prompt the user for height in interval [1, 8]
    int height;
    do
    {
        height = get_int("Height: ");
    }
    while (!(1 <= height && height <= 8));

    // For line with starting number of 1
    for (int i = 1; i < height + 1; i++)
    {
        // Right aligned pyramid
        line(" ", height - i);
        line("#", i);

        // Print a gap (two spaces)
        printf("  ");

        // Left aligned pyramid
        line("#", i);

        // Go to the next line
        printf("\n");
    }
}

// Prints a string n times in the same line
void line(string text, int n)
{
    for (int i = 0; i < n; i++)
    {
        printf("%s", text);
    }
}