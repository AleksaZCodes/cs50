#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char rotate(char c, string key);

int main(int argc, string argv[])
{
    // Check for valid argument count
    if (argc == 2)
    {
        // Check for valid key
        if (strlen(argv[1]) == 26)
        {
            string key = argv[1];

            // Prompt the user for plaintext
            string plain = get_string("plaintext:  ");

            // For every char in the string, rotate and print it
            printf("ciphertext: ");
            for (int i = 0, len = strlen(plain); i < len; i++)
            {
                printf("%c", rotate(plain[i], key));
            }
            printf("\n");
        }
        else
        {
            // Error message
            printf("Key must contain 26 characters.\n");
            return 1;
        }
    }
    else
    {
        // Usage instructions
        printf("Usage: ./substitution key\n");
        return 1;
    }
}

// A function that returns substituted char
char rotate(char c, string key)
{
    if (isupper(c))
    {
        return toupper(key[c - 'A']);
    }
    else if (islower(c))
    {
        return tolower(key[c - 'a']);
    }
    else
    {
        return c;
    }
}