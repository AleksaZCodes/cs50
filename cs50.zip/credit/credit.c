#include <cs50.h>
#include <stdio.h>

string card_type(long number);

int main(void)
{
    // Prompt the user for the card number
    long number;
    number = get_long("Number: ");

    // Check if it has at least 13 and at most 16 digits
    if (number < 1000000000000 || number > 9999999999999999)
    {
        printf("INVALID\n");
        return 0;
    }

    // Check for a type of card and if it's valid
    string card = card_type(number);
    if (card == "INVALID")
    {
        printf("%s\n", card);
        return 0;
    }

    return 0;
}

// Returns the card type based on specs or "INVALID"
string card_type(long number)
{
    // First check if it doesn't have at least 13 and at most 16 digits
    if (number < 1000000000000 || number > 9999999999999999)
    {
        return "INVALID";
    }
}