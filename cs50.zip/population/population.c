#include <cs50.h>
#include <stdio.h>

int main(void)
{
    // TODO: Prompt for start size
    int llamas;
    do
    {
        llamas = get_int("Start size: ");
    }
    while (llamas < 9);

    // TODO: Prompt for end size
    int end;
    do
    {
        end = get_int("End size: ");
    }
    while (end < llamas);

    // TODO: Calculate number of years until we reach threshold
    int years = 0;
    while (llamas < end)
    {
        llamas = llamas + (llamas / 3) - (llamas / 4);
        years++;
    }

    // TODO: Print number of years
    printf("Years: %i\n", years);

    return 0;
}
